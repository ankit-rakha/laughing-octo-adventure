package com.thinkaurelius.faunus.formats.titan.cassandra;

import com.thinkaurelius.faunus.formats.titan.TitanOutputFormat;

/**
 * @author Marko A. Rodriguez (http://markorodriguez.com)
 */
public class TitanCassandraOutputFormat extends TitanOutputFormat {

}