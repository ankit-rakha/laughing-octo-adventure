package com.thinkaurelius.faunus.formats.titan.hbase;

import com.thinkaurelius.faunus.formats.titan.TitanOutputFormat;

/**
 * @author Marko A. Rodriguez (http://markorodriguez.com)
 */
public class TitanHBaseOutputFormat extends TitanOutputFormat {

}