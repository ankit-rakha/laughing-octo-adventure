package com.thinkaurelius.faunus.formats.graphson;

import com.thinkaurelius.faunus.FaunusEdge;
import com.thinkaurelius.faunus.FaunusVertex;
import org.codehaus.jettison.json.JSONObject;

import java.io.IOException;

import static com.tinkerpop.blueprints.Direction.IN;
import static com.tinkerpop.blueprints.Direction.OUT;

/**
 * @author Stephen Mallette (http://stephen.genoprime.com)
 */
public class GraphSONScaffold {

    public static void main(final String[] args) throws Exception {
        int max = Integer.parseInt(args[0]) * 1000000;
        Thread.sleep(15000);
        doToJson(max);
    }

    private static void doToJson(int max) throws IOException {
        for (int ix = 0; ix < max; ix++) {
            FaunusVertex marko = new FaunusVertex(1l);
            marko.setProperty("name", "marko");
            FaunusVertex stephen = new FaunusVertex(2l);
            stephen.setProperty("name", "stephen");
            FaunusVertex vadas = new FaunusVertex(3l);
            vadas.setProperty("name", "vadas");

            marko.addEdge(OUT, new FaunusEdge(marko.getIdAsLong(), stephen.getIdAsLong(), "knows")).setProperty("weight", 2);
            marko.addEdge(IN, new FaunusEdge(vadas.getIdAsLong(), marko.getIdAsLong(), "knows")).setProperty("weight", 1);

            System.out.println(GraphSONUtility.toJSON(marko));
            System.out.println(GraphSONUtility.toJSON(stephen));
            System.out.println(ix);
        }
    }
}
